﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.IO;


namespace WebApplication1.Models
{

    public class Emp_DB_Detail
    {
        #region Variable Defination...
        string StrConnection = "";
        SqlConnection conSql = null;
        SqlCommand cmdSQL = null;
        List<Employee> _lstEmployee = null;
        bool bResult = false;
        #endregion

        public string StrErrorMsg { get; set; }

        #region Reading Configuration...
        public Emp_DB_Detail()
        {
            var configuration = GetConfiguration();
            StrConnection = configuration.GetConnectionString("connection");
        }

        public IConfigurationRoot GetConfiguration()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            return builder.Build();
        }
        #endregion

        #region User defined functions...
        public List<Employee> GetEmpDetail()
        {
            SqlDataReader objDr = null;
            try
            {
                _lstEmployee = new List<Employee>();
                conSql = new SqlConnection(StrConnection);
                cmdSQL = new SqlCommand("usp_getEmployeeInfo", conSql);
                cmdSQL.CommandType = CommandType.StoredProcedure;
                conSql.Open();
                objDr = cmdSQL.ExecuteReader();
                while (objDr.Read())
                {
                    using (Employee clsEmp = new Employee())
                    {
                        clsEmp.IntSrNo = Convert.ToInt32(objDr["SrNo"]);
                        clsEmp.StrName = objDr["Name"].ToString();
                        clsEmp.StrDepartment = objDr["Department"].ToString();
                        clsEmp.StrCity = objDr["City"].ToString();
                        _lstEmployee.Add(clsEmp);
                    }
                }


            }
            catch (Exception ex)
            {
                //throw exception
                StrErrorMsg = ex.Message;

            }
            finally
            {
                //cleaning objects/memory
                if (objDr != null)
                {
                    objDr.Close();
                    objDr = null;
                }


                if (conSql != null)
                {
                    conSql.Close();
                    conSql.Dispose();
                    conSql = null;
                }
            }

            return _lstEmployee;
        }

        public bool AddEmpDetail(Employee moduleEmp)
        {
            
            bResult = ExecuteProcedure("CREATE", "usp_InsertEmployeeInfo", moduleEmp);
            return bResult;
        }

        public bool UpdateEmpDetail(Employee moduleEmp)
        {
            
            bResult = ExecuteProcedure("UPDATE", "usp_UpdateEmployeeInfo", moduleEmp);
            return bResult;
        }

        public bool DeleteEmpDetail(int iSrNo)
        {
           
            Employee moduleEmp = new Employee();
            moduleEmp.IntSrNo = iSrNo;
            bResult = ExecuteProcedure("DELETE", "usp_deleteEmployeeInfo", moduleEmp);
            return bResult;
        }

        public bool ExecuteProcedure(string strAction, string strProcedure, Employee moduleEmp)
        {
            bool bResult = false;
            try
            {
                // List<Employee> _lstEmployee = new List<Employee>();
                conSql = new SqlConnection(StrConnection);
                cmdSQL = new SqlCommand(strProcedure, conSql);
                cmdSQL.CommandType = CommandType.StoredProcedure;

                conSql.Open();

                switch (strAction)
                {
                    case "CREATE":
                    case "UPDATE":
                        cmdSQL.Parameters.AddWithValue("@srno", moduleEmp.IntSrNo);
                        cmdSQL.Parameters.AddWithValue("@name", moduleEmp.StrName);
                        cmdSQL.Parameters.AddWithValue("@city", moduleEmp.StrCity);
                        cmdSQL.Parameters.AddWithValue("@dept", moduleEmp.StrDepartment);
                        break;

                    case "DELETE":
                        cmdSQL.Parameters.AddWithValue("@srno", moduleEmp.IntSrNo);
                        break;

                    default:
                        break;
                }


                int iResult = cmdSQL.ExecuteNonQuery();
                if (iResult > 0)
                    bResult = true;
                else
                    bResult = false;
            }
            catch (Exception ex)
            {
                StrErrorMsg = ex.Message;
                bResult = false;
            }
            finally
            {
                //cleaning objects/memory
                if (cmdSQL != null)
                {
                    cmdSQL.Dispose();
                    cmdSQL = null;
                }

                if (conSql != null)
                {
                    conSql.Close();
                    conSql.Dispose();
                    conSql = null;
                }
            }

            return bResult;
        }
        #endregion
    }
}
