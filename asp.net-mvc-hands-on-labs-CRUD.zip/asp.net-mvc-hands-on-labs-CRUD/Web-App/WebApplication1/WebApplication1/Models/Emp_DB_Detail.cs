﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.IO;


namespace WebApplication1.Models
{
    
    public class Emp_DB_Detail
    {
        #region Variable Defination...
        string szConnectionString = "";
        SqlConnection objCon = null;
        #endregion

        #region Reading Configuration...
        public Emp_DB_Detail()
        {
            var configuration = GetConfiguration();
            szConnectionString =configuration.GetConnectionString("connection");
        }

        public IConfigurationRoot GetConfiguration()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            return builder.Build();
        }
        #endregion

        #region User defined functions...
        public List<Employee> getEmpDetail()
        {
            List<Employee> empList = new List<Employee>();
            SqlConnection conSQL = new SqlConnection(szConnectionString);
            SqlCommand cmdSQL = new SqlCommand("sp_getEmployeeInfo", conSQL);
            cmdSQL.CommandType = CommandType.StoredProcedure;
            conSQL.Open();
            SqlDataReader objDr = cmdSQL.ExecuteReader();
            while (objDr.Read())
            {
                Employee clsEmp = new Employee();
                clsEmp.SrNo = Convert.ToInt32(objDr["SrNo"]);
                clsEmp.Name = objDr["Name"].ToString();
                clsEmp.Department = objDr["Department"].ToString();
                clsEmp.City = objDr["City"].ToString();
                empList.Add(clsEmp);

            }

            //cleaning objects/momory
            if (objDr != null)
            {
                objDr.Close();
                objDr = null;
            }


            if (conSQL != null)
            {
                conSQL.Close();
                conSQL.Dispose();
                conSQL = null;
            }



            return empList;
        }

        public bool AddEmpDetail(Employee objEmp)
        {
            bool bResult = false;

            List<Employee> empList = new List<Employee>();
            SqlConnection conSQL = new SqlConnection(szConnectionString);
            SqlCommand cmdSQL = new SqlCommand("sp_InsertEmployeeInfo", conSQL);
            cmdSQL.CommandType = CommandType.StoredProcedure;

            cmdSQL.Parameters.AddWithValue("@srno", objEmp.SrNo);
            cmdSQL.Parameters.AddWithValue("@name", objEmp.Name);
            cmdSQL.Parameters.AddWithValue("@city", objEmp.City);
            cmdSQL.Parameters.AddWithValue("@dept", objEmp.Department);

            conSQL.Open();
            int iResult = cmdSQL.ExecuteNonQuery();
            if (iResult > 0)
                bResult = true;
            else
                bResult = false;

            //cleaning objects/momory
            if (conSQL != null)
            {
                conSQL.Close();
                conSQL.Dispose();
                conSQL = null;
            }

            return bResult;
        }

        public bool UpdateEmpDetail(Employee objEmp)
        {
            bool bResult = false;

            List<Employee> empList = new List<Employee>();
            SqlConnection conSQL = new SqlConnection(szConnectionString);
            SqlCommand cmdSQL = new SqlCommand("sp_UpdateEmployeeInfo", conSQL);
            cmdSQL.CommandType = CommandType.StoredProcedure;

            cmdSQL.Parameters.AddWithValue("@srno", objEmp.SrNo);
            cmdSQL.Parameters.AddWithValue("@name", objEmp.Name);
            cmdSQL.Parameters.AddWithValue("@city", objEmp.City);
            cmdSQL.Parameters.AddWithValue("@dept", objEmp.Department);

            conSQL.Open();
            int iResult = cmdSQL.ExecuteNonQuery();
            if (iResult > 0)
                bResult = true;
            else
                bResult = false;


            //cleaning objects/momory
            if (conSQL != null)
            {
                conSQL.Close();
                conSQL.Dispose();
                conSQL = null;
            }

            return bResult;
        }


        public bool DeleteEmpDetail(int iSrNo)
        {
            bool bResult = false;

            List<Employee> empList = new List<Employee>();
            SqlConnection conSQL = new SqlConnection(szConnectionString);
            SqlCommand cmdSQL = new SqlCommand("sp_deleteEmployeeInfo", conSQL);
            cmdSQL.CommandType = CommandType.StoredProcedure;

            cmdSQL.Parameters.AddWithValue("@srno", iSrNo);

            conSQL.Open();
            int iResult = cmdSQL.ExecuteNonQuery();
            if (iResult > 0)
                bResult = true;
            else
                bResult = false;


            //cleaning objects/momory
            if (conSQL != null)
            {
                conSQL.Close();
                conSQL.Dispose();
                conSQL = null;
            }

            return bResult;
        }
        #endregion
    }
}
