﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{

    public class Employee : IDisposable
    {
        #region Properties...

        [Required] //validation
        public int IntSrNo { get; set; }

        [Required] //validation
        public string StrName { get; set; }

        [Required] //validation
        public string StrCity { get; set; }

        [Required] //validation
        public string StrDepartment { get; set; }
        #endregion

        public void Dispose()
        {
            // Release resources, close any connections, etc... 
        }

    }



}
