﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{

    public class Employee
    {
        #region Properties...

        [Required] //validation
        public int SrNo { get; set; }
        
        [Required] //validation
        public string Name { get; set; }

        [Required] //validation
        public string City { get; set; }

        [Required] //validation
        public string Department { get; set; }
        #endregion
    }
}
