﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using WebApplication1.Models;
using Microsoft.Extensions.Configuration;

namespace WebApplication1.Controllers
{
    public class EmpController : Controller
    {
        public IActionResult Index()
        {
          


            Models.Emp_DB_Detail clsDbDetail = new Models.Emp_DB_Detail();
            List<Models.Employee> objEmpList = clsDbDetail.getEmpDetail();
            return View(objEmpList);
        }

        public IActionResult Create()
        {
            return View();
        }

        
        //below method call when we click on CREATE link button
        [HttpPost]
        public IActionResult Create(Employee objEmp)
        {
            if (ModelState.IsValid)
            {
                Emp_DB_Detail objEmpDB = new Emp_DB_Detail();

                bool bResult = objEmpDB.AddEmpDetail(objEmp);

                TempData["Messsage"] = "Data inserted successfully";
                ModelState.Clear();
                return RedirectToAction("Index");

            }
            return View();
        }

        public IActionResult Edit(int id)
        {
            Emp_DB_Detail objEmpDB = new Models.Emp_DB_Detail();
            var row = objEmpDB.getEmpDetail().Find(model => model.SrNo == id);
            return View(row);
        }


        //below method call when we click on EDIT link button
        [HttpPost]
        public IActionResult Edit(int id, Employee objEmp)
        {
            if (ModelState.IsValid)
            {
                Emp_DB_Detail objEmpDB = new Emp_DB_Detail();

                bool bResult = objEmpDB.UpdateEmpDetail(objEmp);

                TempData["UpdateMesssage"] = "Data Updated successfully";
                ModelState.Clear();
                return RedirectToAction("Index");

            }
            return View();
        }


        public IActionResult Delete(int id)
        {
            Emp_DB_Detail objEmpDB = new Models.Emp_DB_Detail();
            var row = objEmpDB.getEmpDetail().Find(model => model.SrNo == id);
            return View(row);
        }


        //below method call when we click on DELETE link button
        [HttpPost]
        public IActionResult Delete(int id, Employee objEmp)
        {

            Emp_DB_Detail objEmpDB = new Emp_DB_Detail();

            bool bResult = objEmpDB.DeleteEmpDetail(id);

            if (bResult)
            {
                TempData["deleteMesssage"] = "Data Deleted successfully";

                return RedirectToAction("Index");
            }

            return View();
        }
    }
}
