﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using WebApplication1.Models;
using Microsoft.Extensions.Configuration;

namespace WebApplication1.Controllers
{
    public class EmpController : Controller
    {
        Emp_DB_Detail clsEmpDB = null;

        public IActionResult Index()
        {

            Models.Emp_DB_Detail clsDbDetail = new Models.Emp_DB_Detail();
            List<Models.Employee> objEmpList = clsDbDetail.GetEmpDetail();
            return View(objEmpList);
        }

        public IActionResult Create()
        {
            return View();
        }


        //below method call when we click on CREATE link button
        [HttpPost]
        public IActionResult Create(Employee objEmp)
        {
            if (ModelState.IsValid)
            {
                clsEmpDB = new Emp_DB_Detail();

                bool bResult = clsEmpDB.AddEmpDetail(objEmp);

                if (bResult)
                    TempData["Messsage"] = "Data inserted successfully";
                else
                    TempData["Messsage"] = "Error occurred " + clsEmpDB.StrErrorMsg;

                ModelState.Clear();
                return RedirectToAction("Index");

            }
            return View();
        }

        public IActionResult Edit(int id)
        {
            clsEmpDB = new Models.Emp_DB_Detail();
            var row = clsEmpDB.GetEmpDetail().Find(model => model.IntSrNo == id);
            return View(row);
        }


        //below method call when we click on EDIT link button
        [HttpPost]
        public IActionResult Edit(int id, Employee objEmp)
        {
            if (ModelState.IsValid)
            {
                clsEmpDB = new Emp_DB_Detail();

                bool bResult = clsEmpDB.UpdateEmpDetail(objEmp);


                if (bResult)
                    TempData["Messsage"] = "Data Updated  successfully";
                else
                    TempData["Messsage"] = "Error occurred " + clsEmpDB.StrErrorMsg;

                ModelState.Clear();
                return RedirectToAction("Index");

            }
            return View();
        }


        public IActionResult Delete(int id)
        {
            clsEmpDB = new Models.Emp_DB_Detail();
            var row = clsEmpDB.GetEmpDetail().Find(model => model.IntSrNo == id);
            return View(row);
        }


        //below method call when we click on DELETE link button
        [HttpPost]
        public IActionResult Delete(int id, Employee objEmp)
        {

            clsEmpDB = new Emp_DB_Detail();

            bool bResult = clsEmpDB.DeleteEmpDetail(id);

            if (bResult)
                TempData["Messsage"] = "Data deleted successfully";
            else
                TempData["Messsage"] = "Error occurred " + clsEmpDB.StrErrorMsg;

          return RedirectToAction("Index");


           /// return View();
        }
    }
}
